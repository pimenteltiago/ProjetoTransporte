﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projPilhaTransporte.model {
    class Transporte {
        
        //Atributos
        private Veiculo veiculo;
        private int qtdeTransportada;

        // Getters e Setters
        public int QtdeTransportada { get => qtdeTransportada; set => qtdeTransportada = value; }
        internal Veiculo Veiculo { get => veiculo; set => veiculo = value; }

        //Construtor
        public Transporte(Veiculo veiculo, int qtdeTransportadora) {

        }
    }
}
